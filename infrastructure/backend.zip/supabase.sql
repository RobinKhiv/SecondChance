-- In Supabase SQL editor

-- Users table
create table public.users (
  id uuid default uuid_generate_v4() primary key,
  email text unique not null,
  password text not null,
  avatar text,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Items table
create table public.items (
  id uuid default uuid_generate_v4() primary key,
  title text not null,
  description text,
  price decimal(10,2) not null,
  images jsonb,
  seller_id uuid references public.users(id),
  buyer_id uuid references public.users(id),
  purchase_date timestamp with time zone,
  created_at timestamp with time zone default timezone('utc'::text, now()),
  condition text,
  category text,
  status text default 'active'
);

-- Row Level Security
alter table public.users enable row level security;
alter table public.items enable row level security;

-- Policies
create policy "Users can read their own data" on public.users
  for select using (auth.uid() = id);

create policy "Anyone can read active items" on public.items
  for select using (status = 'active');

create policy "Users can create items" on public.items
  for insert with check (auth.uid() = seller_id);

create policy "Sellers can update their items" on public.items
  for update using (auth.uid() = seller_id);
